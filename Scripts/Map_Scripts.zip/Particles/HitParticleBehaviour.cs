﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitParticleBehaviour : MonoBehaviour {

	public AudioSource SurfaceParticleAudioSource;
	public AudioClip[] SurfaceParticleSoundEffects;

	void Start()
	{
		SurfaceParticleAudioSource.PlayOneShot (SurfaceParticleSoundEffects [Random.Range (0, SurfaceParticleSoundEffects.Length - 1)], 1f); //Plays a random hit sound from the SurfaceParticleSoundEffects Array
	}
}

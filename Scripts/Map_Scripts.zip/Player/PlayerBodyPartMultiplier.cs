﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBodyPartMultiplier : MonoBehaviour {

	public float DamageModifier = 1f;
}

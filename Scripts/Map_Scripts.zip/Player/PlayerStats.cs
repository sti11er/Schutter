﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour {

	[Header("Player Attributes")]
	public int PlayerHealth = 100;			//Health variable on the local player | 
	public bool isAlive = true;				//Tells if this player is still alive or not
	public PunTeams.Team PlayerTeam;		//The team this player is currently on

	[Header("Player Sound Effects")]
	[Range(0f,1f)]
	public float FootStepVolume = 0.5f;
	public AudioSource FootstepAudiosource;
	public AudioClip[] FootstepSounds;
	public AudioClip FootStepLandSound;
	public float StepInterval;
	public float RunMultiplier = 1;
	public float StepTimer;
	public AudioClip PlayerWaterWadeSound;
	public AudioClip PlayerWaterEnterSound;
	[Space(10)]
	[Range(0f,1f)]
	public float GearSoundVolume = 0.4f;
	public AudioClip GearPlayerLandSound;
	public AudioSource PlayerGearAudioSource;

	[Space(10)]
	[Range(0f,1f)]
	public float BreathSoundVolume = 0.4f;
	public AudioSource PlayerBreathAudioSource;
	public AudioClip[] PlayerSprintBreathSounds;
	[Range(0f,3f)]
	public float SprintBreathInterval;
	public float SprintBreathTimer;

	[Header("Player References")]
	public Text PlayerNameText;				//The playername text which is above the player object
	public CharacterController PlayerCharacterController;	//Local reference to the PlayerCharacterController
	public PlayerMovementController PlayerMovementController;	//Local reference to the PlayerMovementController
	public PlayerWeaponManager PlayerWeaponManager;				//Local reference to the PlayerWeaponManager
	public PlayerThirdPersonController PlayerThirdPersonController;	//Local reference to the PlayerThirdPersonController
	public PhotonView PlayerPhotonView;		//The photonview attached to this player object

	void Start()
	{
		if (PlayerPhotonView.isMine) {	//If we are the owner of this playerobject's photonview
			PhotonNetwork.player.TagObject = this.gameObject;	//Get the localplayer object and store it in the PhotonNetwork.player.TagObject variable for later use
			InGameUI.instance.PlayerHealthText.text = PlayerHealth.ToString ();	//Set the Player Health value in the HUD
			PlayerNameText.gameObject.SetActive (false);						//Disable the playername text above the player for us
			PlayerPhotonView.RPC ("SyncPlayerTeam", PhotonTargets.AllBuffered, PlayerTeam);	//Sync the teamname and set the playername text for other players to the correct team color
		} 
	}

	[PunRPC]
	public void SyncPlayerTeam(PunTeams.Team SyncPlayerTeam)
	{
		PlayerTeam = SyncPlayerTeam;
		SetPlayerNameText ();
	}

	public void SetPlayerNameText()
	{
		if (PlayerTeam == PunTeams.Team.red || PlayerTeam == PunTeams.Team.none) { //If this player is a red / dm enemy player then give their name tag a red color
			PlayerNameText.text = "<color=red>" + PlayerPhotonView.owner.NickName + "</color>";
			this.gameObject.name = PlayerPhotonView.owner.NickName;
		} else if(PlayerTeam == PunTeams.Team.blue){
			PlayerNameText.text = "<color=blue>" + PlayerPhotonView.owner.NickName + "</color>"; //If this player is a blue team player then give their name tag a blue color
			this.gameObject.name = PlayerPhotonView.owner.NickName;
		}
	}

	[PunRPC]
	public void ApplyPlayerDamage(int dmg, string source, PhotonPlayer attacker, float dmgmod, bool SelfInflicted)
	{
		if (attacker.GetTeam() == PunTeams.Team.none || GameManager.instance.CurrentTeam != attacker.GetTeam() || attacker == PhotonNetwork.player || source == "RoadKill") { //If player who damaged us is from team none, not from our own team or we damaged ourself
			if (PlayerHealth > 0) {		//If this players health is above 0
				PlayerHealth -= Mathf.RoundToInt(dmg * dmgmod);	//Subtract the damage from the player with accounting for the damage modifier
				if (PlayerPhotonView.isMine) {	//If the damaged player is our player instance
					InGameUI.instance.DoHitscreen (1f);	//Show the red hitscreen to indicate we are being attacked
					if (PlayerHealth <= 0) {			//If our health is below 0
						PlayerHealth = 0;				//Set our health to 0
						if (source != "RoadKill") { //If we arent killed inside of a vehicle
							PlayerPhotonView.RPC ("OnPlayerKilled", PhotonTargets.All, source, attacker, SelfInflicted); //Send out an rpc to let others know we are dead
						} else {
							if (attacker == null) {
								PlayerPhotonView.RPC ("OnPlayerKilled", PhotonTargets.All, "Crashed", PhotonNetwork.player); //Send out an rpc to let others know we crashed our vehicle
							} else {
								PlayerPhotonView.RPC ("OnPlayerKilled", PhotonTargets.All, source, attacker); //Send out an rpc to let others know that someone killed our vehicle
							}
						}
					}
					InGameUI.instance.PlayerHealthText.text = PlayerHealth.ToString ();	//Set the new playerhealth value to the deducted amount
				}
			}
		}
	}

	[PunRPC]
	public void OnPlayerKilled(string source, PhotonPlayer attacker, bool SelfInflicted)
	{
		this.isAlive = false;		//Set this player's alive state to false	
		if (attacker == PhotonNetwork.player && !SelfInflicted && !this.PlayerPhotonView.isMine) {
			EventManager.TriggerEvent ("OnPlayerKilled");
		}
		if (PlayerPhotonView.isMine && GameManager.instance.IsAlive) {		//If this player is our own player and our IsAlive variable on the gamemanager is still true
			InGameUI.instance.PlayerUseText.text = "";		//Hide the playerusetext
			if (attacker.NickName != PhotonNetwork.player.NickName) { //Dont add a kill to the attacker when you are the attacker
				attacker.AddKill (1);	//Add a kill to the player who killed us
				if (GameManager.instance.CurrentGameType.GameTypeLoadName != "CTF") {
					if (attacker.GetTeam () == PunTeams.Team.red) {
						EventManager.TriggerEvent ("AddRedTeamScore");
					} else if (attacker.GetTeam () == PunTeams.Team.blue) {
						EventManager.TriggerEvent ("AddBlueTeamScore");
					}
				} 
			}
			PhotonNetwork.player.AddDeath (1);	//Add a death for our player
			PlayerThirdPersonController.EnableWeaponIK(false);  //Disable the weaponIK on this thirdperson playermodel
			GameManager.instance.gameObject.GetComponent<PhotonView> ().RPC ("AddKillFeedEntry", PhotonTargets.All, attacker.NickName, source, PhotonNetwork.playerName); //Tell everyone to add a new killfeed entry with the supplied info
			//Disable this playerobject's functionality

			//These 4 lines are only using with the old playerweapon script
			//if (PlayerWeaponManager.CurrentWeapon.GetComponent<PlayerWeapon> ().IsFireLoop) {	//If we are currently firing a looped fire weapon
			//	PlayerWeaponManager.CurrentWeapon.GetComponent<PlayerWeapon>().StopWeapon();
			//	PlayerThirdPersonController.ThirdPersonPhotonView.RPC ("ThirdPersonStopWeapon", PhotonTargets.Others, null);	//Disable the weaponfire animation on the third person model
			//}
			PlayerMovementController.PlayerLegs.SetActive(false);
			PlayerMovementController.enabled = false;
			//PlayerCharacterController.enabled = false;
			if (!GameManager.instance.InVehicle) {
				PlayerWeaponManager.CurrentWeapon.SetActive (false);
				PlayerWeaponManager.enabled = false;
				PlayerThirdPersonController.ThirdPersonPlayerKilled ();
			}
			InGameUI.instance.PlayerHUDPanel.SetActive (false);
			GameManager.instance.IsAlive = false;	
			GameManager.instance.InVehicle = false;
			Invoke ("PlayerRespawn", GameManager.instance.RespawnDelay);	//Wait till the respawndelay before we are being respawned
		}
	}

	void PlayerRespawn()
	{
		if (GameManager.instance.MatchActive) {						//If the match is still active, so we arent in the pregame or endgame
			EventManager.TriggerEvent ("OnPlayerRespawn");			//Send a message to the gametype to let it handle the respawning
			PhotonNetwork.Destroy (this.gameObject);				//Destroy this player object
		}
	}

	[PunRPC]
	public void PlayFootstepSoundNetwork(string Type)
	{
		if (Type == "Normal") {
			FootstepAudiosource.PlayOneShot (FootstepSounds [Random.Range(0, FootstepSounds.Length)], FootStepVolume); //Play a random footstep sound from the footstep array
		}
		if (Type == "Water") {
			FootstepAudiosource.PlayOneShot (PlayerWaterWadeSound, 0.5f); //Play a the water wade soundeffect
		}
	}

	#region Misc
	[PunRPC]
	public void PlayFXAtPosition(int EffectID, Vector3 Position, Vector3 EffectDirection)
	{
		Instantiate (GameManager.instance.IngameEffectsReferences[EffectID], Position, Quaternion.FromToRotation (Vector3.forward, EffectDirection));
	}
	#endregion
}

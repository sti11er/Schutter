﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBoardEntry : MonoBehaviour {

	public Text PlayerNameText;
	public Text PlayerScoreText;
	public Text PlayerKillsText;
	public Text PlayerDeathsText;
	public Text PlayerPingText;
}
